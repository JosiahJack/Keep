Battle Tank-
--------------
-For Use With Half Life-
Completed Saturday February 6th 1999
-Created by Josh Bellows (Mojo) 
-------------------------- 

Filename: Tank01.rmf, and Tank01.map
          (If your missing something, let me know ok?)

Email: Tell me what you think at : imshaft@hotmail.com

HomePage: None

Description: A full sized battle tank for use with halflife. 
Has a working motar cannon that wastes ass!
--------------------------------------------------------
Constrution:
-Based on a warhammer 40k Tank, but it turned out differently
than I expected. Oh well...

Editor: Worldcraft

Build Time: Approximately 3-4 hours. (My first Prefab)

Textures: Tank Textures (Halflife.wad)

Bugs: None that I can find but if there are any, please tell me.
(Tank can be hard to get into at first though.)

Solids: 76
Faces: 489
PointEntities: 10
SolidEntities: 7
 
Use of this file:
---------------------
Do whatever the hell you want!

It's made to improve your worldcraft maps, so just go crazy.
If you are going to create a map with it though, at least have
the deasency to give me some credit...
(Afterall I spent some time on this thing.)

"Happy Fragging!" 
-Mojo
