***************************************************

Title:			   : Target Range
Description:		   : Prefab for Half-Life
Filenames:		   : targets.map
Author                     : Clem Samuel aka Mardegun
Authors E-mail Address	   : cgsamuel@students.wisc.edu
***************************************************

* Information *

New Textures               : No
Entities                   : 22
Solids                     : 41 
Faces                      : 252 
 

Yet, another person with their first prefab ... :).  This a smaller and less detailed target range then what will be in my SP game.  Both Targets move forward then back and there is also an assortment guns to use.


* Legal Stuff *
I don't care if you use this or modify it, as long as you give me credit.  I would like to be contacted if this prefab (or modified) ends up in a finished project.
Have fun!


-Mardegun 
