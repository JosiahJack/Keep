Star Wars A-Wing by Todd Fleck

Prefab = A-Wing
Construction by = Todd Fleck
E-Mail = Braincase3@aol.com or toddfleck@garbage.com
Date = Wed, Mar. 17, 1999.
Faces = 710
Solids = 117
Point Entities = 07
Solid Entities = 03

This is a worldcraft prefab depicting the popular A-Wing spacecraft from Star Wars, This 
Prefab has a sliding canopy, semi-detailed cockpit, heads up display, landing gears, engine and cockpit lighting.  
Please feel free to manipulate and change, but if you do please give me credit for original design.  If you use this prefab in a level, 
E-Mail me and let me know so I can check it out. Thanks and Happy worldcrafting. 

Vehicles
<TABLE BORDER=0><TR>
<TD><IMG SRC="/prefablab/screenshots/tfawing_1.gif" WIDTH=200 HEIGHT=150 ALIGN=Left></TD>
<TD>
<FONT FACE="Verdana, Arial, Helvetica" SIZE="2">
<FONT COLOR="Teal"><U>File:</U></FONT> <A TARGET="prefablabdl" HREF="http://www.planethalflife.com/dl/dl.asp?planethalflife/prefablab/awing.zip">awing.zip (63 K)</A><BR>
<FONT COLOR="Teal"><U>Submitted By:</U></FONT> <A HREF="mailto:Braincase3@aol.com">Todd Fleck</A><BR>
04/20/99<BR>
<BR>
<FONT COLOR="Teal"><U>Solids:</U></FONT> 710<BR>
<FONT COLOR="Teal"><U>Faces:</U></FONT> 117<BR>
<FONT COLOR="Teal"><U>Entities:</U></FONT> 10<BR>
<FONT COLOR="Teal"><U>Formats:</U></FONT> .map<BR>
<FONT COLOR="Teal"><U>Custom Textures:</U></FONT> None<BR>
<BR></TD>
</TR></TABLE>
Star Wars A-wing
</FONT>
<HR WIDTH=100%>
